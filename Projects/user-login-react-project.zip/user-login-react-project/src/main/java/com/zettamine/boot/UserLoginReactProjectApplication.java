package com.zettamine.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserLoginReactProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserLoginReactProjectApplication.class, args);
	}

}
